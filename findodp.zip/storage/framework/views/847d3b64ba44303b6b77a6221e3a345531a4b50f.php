
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>ODC</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">User</a></div>
                    <div class="breadcrumb-item"><a href="#">ODC</a></div>

                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">Data ODC</h2>

                <div class="row">
                    <div class="col-12">
                        <div class="card">



                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="w-full h-96 relative flex bg-gray-400" id="mapid"></div>
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped" id="table-1">
                                                    <thead>
                                                        <tr>
                                                            <th>
                                                                NO
                                                            </th>
                                                            <th>Nama OLT</th>
                                                            <th>Nama ODC</th>
                                                            <th>Alamat</th>

                                                            <th>Latitude</th>
                                                            <th>Longitude</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $odc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $odc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <?php echo e($index + 1); ?>


                                                                </td>
                                                                <td><?php echo e($odc->olt->nama); ?></td>
                                                                <td><?php echo e($odc->nama); ?></td>
                                                                <td><?php echo e($odc->alamat); ?></td>

                                                                <td><?php echo e($odc->latitude); ?></td>
                                                                <td><?php echo e($odc->longitude); ?></td>
                                                                <td>

                                                                    <a href="<?php echo e(route('user.odc.show', $odc->id)); ?>"
                                                                        class="btn btn-info">Survey</a>



                                                                </td>
                                                            </tr>
                                                            <input type="hidden" value="<?php echo e($odc->id); ?>"
                                                                id="id<?php echo e($loop->index); ?>">
                                                            <input type="hidden" value="<?php echo e($odc->nama); ?>"
                                                                id="nama<?php echo e($loop->index); ?>">
                                                            <input type="hidden" value="<?php echo e($odc->alamat); ?>"
                                                                id="alamat<?php echo e($loop->index); ?>">
                                                            <input type="hidden" value="<?php echo e($odc->latitude); ?>"
                                                                id="lat<?php echo e($loop->index); ?>">
                                                            <input type="hidden" value="<?php echo e($odc->longitude); ?>"
                                                                id="lon<?php echo e($loop->index); ?>">
                                                            <?php
                                                                $a = '';
                                                                $a = $loop->index;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                        <input type="hidden" value="<?php echo e($a ?? ''); ?>" id="index">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
        integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
        crossorigin="" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol/dist/L.Control.Locate.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
    <script src="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol/dist/L.Control.Locate.min.js" charset="utf-8"></script>


    <script>
        var mymap = L.map('mapid').setView([-7.563828, 110.8173266], 8);
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            maxZoom: 18,
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1,
            accessToken: 'sk.eyJ1IjoibWFyaWZmaW4iLCJhIjoiY2tqM3V3OHByMGY4ejJybnE0ZDZpN2JpdSJ9.VkZp3cjQSPoL7lpc-VWsCg'
        }).addTo(mymap);
        var a = []
        var longlat = [];
        var label = [];
        var marker = [];
        var index = document.getElementById('index').value;
        if (index == '') {
            var a = 1;
        } else {
            // Coordinate
            for (c = 0; c <= index; c++) {
                var lat = parseFloat(document.getElementById('lat' + [c]).value);
                var lon = parseFloat(document.getElementById('lon' + [c]).value);
                var arr = [lat, lon];
                longlat.push(arr);

            }
            // LabelPopup

            for (d = 0; d <= index; d++) {
                var nama = document.getElementById('nama' + [d]).value;
                var alamat = document.getElementById('alamat' + [d]).value;
                var arr = [nama, alamat];
                label.push(arr);
            }
            for (i = 0; i < longlat.length; i++) {
                var push = L.marker(longlat[i]).addTo(mymap)
                marker.push(push);

            }

            for (a = 0; a < label.length; a++) {
                marker[a].bindPopup("Nama ODC = " + label[a][0] + "<br>" + "Alamat = " + label[a][1]);
            }
        }


        // var marker = L.marker([-7.514980942395872, 110.93994140625001]).addTo(mymap);
        lc = L.control.locate({
            strings: {
                title: "Lokasi Mu Saat ini!!"
            }
        }).addTo(mymap);
    </script>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel project\findodp\resources\views/user/odc/index.blade.php ENDPATH**/ ?>