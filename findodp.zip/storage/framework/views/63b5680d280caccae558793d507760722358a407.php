
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Graph</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item"><a href="#">Graph</a></div>
                    <div class="breadcrumb-item"><a href="#">ODP</a></div>

                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">Graph ODP</h2>

                <div class="row">
                    <div class="col-12">
                        <div class="card">

                            <div id="chart-container">
                                <?php echo $chart->container(); ?>

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
    <?php echo $chart->script(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel project\findodp\resources\views/admin/graph/odp.blade.php ENDPATH**/ ?>