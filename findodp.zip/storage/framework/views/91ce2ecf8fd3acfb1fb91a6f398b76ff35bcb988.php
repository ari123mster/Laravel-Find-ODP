
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>OLT</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item"><a href="#">OLT</a></div>

                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">Data OLT</h2>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <form action="">
                                    <button class="btn btn-primary">Tambah</button>
                                </form>
                            </div>
                            

                            <div class="row">
                                <div class="col-12">
                                    <div class="card">

                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped" id="table-1">
                                                    <thead>
                                                        <tr>
                                                            <th>
                                                                NO
                                                            </th>
                                                            <th>Nama OLT</th>
                                                            <th>Alamat</th>
                                                            <th>Slot</th>
                                                            <th>Port</th>
                                                            <th>Latitude</th>
                                                            <th>Longitude</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $olt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $olt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo e($index + 1); ?>


                                                            </td>
                                                            <td><?php echo e($olt->nama); ?></td>
                                                            <td><?php echo e($olt->alamat); ?></td>
                                                            <td><?php echo e($olt->slot); ?></td>
                                                            <td><?php echo e($olt->port); ?></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td>
                                                                <a href="" class="btn btn-warning">Edit</a>
                                                                <a href="" class="btn btn-info">Survey</a>
                                                                <a href="" class="btn btn-danger">Hapus</a>

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel project\findodp\resources\views/admin/olt/index.blade.php ENDPATH**/ ?>