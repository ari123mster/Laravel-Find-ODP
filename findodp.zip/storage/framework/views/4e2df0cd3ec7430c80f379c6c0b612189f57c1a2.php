
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>user</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item"><a href="#">user</a></div>

                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">Data user</h2>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <form action="<?php echo e(route('admin.user.create')); ?>">
                                    <button class="btn btn-primary">Tambah</button>
                                </form>
                            </div>


                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped" id="table-1">
                                                    <thead>
                                                        <tr>
                                                            <th>
                                                                NO
                                                            </th>
                                                            <th>Nama</th>
                                                            <th>Email</th>
                                                            
                                                            <th>Password</th>


                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <?php echo e($index + 1); ?>


                                                                </td>
                                                                <td><?php echo e($user->name); ?></td>
                                                                <td><?php echo e($user->email); ?></td>
                                                                
                                                                <td><?php echo e($user->password); ?></td>


                                                                <td>
                                                                    <form
                                                                        action="<?php echo e(route('admin.user.destroy', $user->id)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="btn btn-danger d-inline">
                                                                            hapus
                                                                        </button>

                                                                        <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>"
                                                                            class="btn btn-warning ">Edit</a>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel project\findodp\resources\views/admin/user/index.blade.php ENDPATH**/ ?>