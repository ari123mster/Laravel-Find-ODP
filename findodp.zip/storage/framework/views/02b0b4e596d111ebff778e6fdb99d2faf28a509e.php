
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <div class="section-header-back">
                    <a href="<?php echo e(route('admin.odp.index')); ?>" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
                </div>
                <h1>ODP</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active"><a href="#">Admin</a></div>
                    <div class="breadcrumb-item"><a href="#">ODP</a></div>
                    <div class="breadcrumb-item"><a href="#">Tambah Data</a></div>
                </div>
            </div>

            <div class="section-body">
                <h2 class="section-title">Tambah Data ODP</h2>

                <section id="multiple-column-form">
                    <div class="row match-height">
                        <div class="col-md-12 ">
                            <div class="card">

                                <div style="z-index: 0" class="w-full h-96 relative flex bg-gray-400" id="maps"></div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.odp.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <label>Nama Olt</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <select class="form-control" name="olt_id">
                                                            <option>..pilih..</option>
                                                            <?php $__currentLoopData = $olt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $olt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($olt->id); ?>"><?php echo e($olt->nama); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Nama odp</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="nama" class="form-control" name="nama">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Alamat</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="alamat" class="form-control" name="alamat">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Jumlah Port</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="port" class="form-control" name="port"
                                                            placeholder="" onkeyup="sum();">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Port Terpakai</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="terpakai" class="form-control"
                                                            name="terpakai" placeholder="" onkeyup="sum();">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Port Kosong</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="total" class="form-control" name="total"
                                                            placeholder="" onkeyup="sum();" readonly>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Latitude</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="latitude" class="form-control"
                                                            name="latitude">
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label>Longitude</label>
                                                    </div>
                                                    <div class="col-md-8 form-group">
                                                        <input type="text" id="longitude" class="form-control"
                                                            name="longitude">
                                                    </div>
                                                    <div class="col-sm-12 d-flex justify-content-end">
                                                        <button type="submit"
                                                            class="btn btn-primary me-1 mb-1">Submit</button>
                                                        <button type="reset"
                                                            class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <input type="hidden" value="<?php echo e($a ?? ''); ?>" id="index">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>



            </div>
    </div>
    </div>
    </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
        integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
        crossorigin="" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol/dist/L.Control.Locate.min.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
    <script src="https://cdn.jsdelivr.net/npm/leaflet.locatecontrol/dist/L.Control.Locate.min.js" charset="utf-8"></script>
    <script>
        var mymap = L.map('maps').setView([-7.449, 109.2150], 6);
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            maxZoom: 18,
            id: 'mapbox/streets-v11',
            tileSize: 512,
            zoomOffset: -1,
            accessToken: 'sk.eyJ1IjoibWFyaWZmaW4iLCJhIjoiY2tqM3V3OHByMGY4ejJybnE0ZDZpN2JpdSJ9.VkZp3cjQSPoL7lpc-VWsCg'
        }).addTo(mymap);
        var popup = L.popup();
        var longlat = [];
        var label = [];
        var marker = [];
        var index = document.getElementById('index').value;
        if (index === '') {
            function onMapClick(e) {
                popup
                    .setLatLng(e.latlng)
                    .setContent("<center>Lokasi yang anda pilih</center><br>Latitude = " + e.latlng.lat + "<br>" +
                        "Longitude = " + e.latlng.lng)
                    .openOn(mymap);
                var a = e.latlng.toString();
                var latitude = e.latlng.lat;
                var longitude = e.latlng.lng;
                document.getElementById('latitude').value = latitude;
                document.getElementById('longitude').value = longitude;


            }

            mymap.on('click', onMapClick);
        } else {
            // Coordinate
            for (c = 0; c <= index; c++) {
                var lat = parseFloat(document.getElementById('lat' + [c]).value);
                var lon = parseFloat(document.getElementById('lon' + [c]).value);
                var arr = [lat, lon];
                longlat.push(arr);
            }


            mymap.on('click', onMapClick);
        }
        lc = L.control.locate({
            strings: {
                title: "Lokasi Mu Saat ini!!"
            }
        }).addTo(mymap);
    </script>
    <script>
        function sum() {
            var txtFirstNumberValue = document.getElementById('port').value;
            var txtSecondNumberValue = document.getElementById('terpakai').value;
            var result = parseInt(txtFirstNumberValue) - parseInt(txtSecondNumberValue);
            if (!isNaN(result)) {
                document.getElementById('total').value = result;
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel project\findodp\resources\views/admin/odp/create.blade.php ENDPATH**/ ?>