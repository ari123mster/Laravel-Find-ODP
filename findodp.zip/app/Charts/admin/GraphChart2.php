<?php

namespace App\Charts\admin;

use ConsoleTVs\Charts\Classes\Chartjs\Chart;

class GraphChart2 extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
